# 🌺 Orchid Garden Website

Project website sederhana bertema bunga anggrek.

## Fitur
- Landing page elegan
- Navigasi sederhana
- Galeri bunga anggrek
- Desain responsif

## Cara Menjalankan
1. Download project
2. Buka file `index.html` di browser

## Author
Mortification Records
